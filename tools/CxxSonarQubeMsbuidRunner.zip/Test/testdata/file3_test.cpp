#include <googletest/gtest.hpp>

class CM_toolFileSystemJapaneseTest: public ::testing::Test
{
public:
	void SetUp() override
	{
	}

	void TearDown() override
	{
	}
};

TEST_F(CM_toolFileSystemJapaneseTest, testFileSystemGets_FilesWithSuffixFromSubFolder)
{
}

TEST_F(CM_toolFileSystemJapaneseTest, testFileSystem_GetFullPathTo)
{
}

TEST_F(CM_toolFileSystemJapaneseTest, testTransform)
{
}
#include <googletest/gtest.hpp>

class MD_cieExportLibraryTest: public ::testing::Test
{
public:
	void SetUp() override
	{
	}

	void TearDown() override
	{
	}
};

TEST_F(MD_cieExportLibraryTest, ExportLibraryCreatesLibrary2Database)
{
}

TEST_F(MD_cieExportLibraryTest, ExportLibraryDestroysLibrary2Database)
{
}

TEST_F(MD_cieExportLibraryTest, ExportLibrarySavesDbToFile)
{
}

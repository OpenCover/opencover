//-----------------------------------------------------------------------
// <copyright file="StoreDetailsViewModel.cs" company="Hibernating Rhinos LTD">
//     Copyright (c) Hibernating Rhinos LTD. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using MvcMusicStore.Models;

namespace MvcMusicStore.ViewModels
{
    public class StoreDetailsViewModel
    {
        public Album Album { get; set; }
    }
}

//-----------------------------------------------------------------------
// <copyright file="SoldAlbum.cs" company="Hibernating Rhinos LTD">
//     Copyright (c) Hibernating Rhinos LTD. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace MvcMusicStore.Models
{
    public class SoldAlbum
    {
        public string Album { get; set; }
        public int Quantity { get; set; }
    }
}

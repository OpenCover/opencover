// stdafx.cpp : source file that includes just the standard includes
//	clstencil.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Classes Reference and related electronic
// documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft C++ Libraries products.

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
